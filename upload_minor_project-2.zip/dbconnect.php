


<?php
// Database configuration
$dbhost="localhost";
$username="root";
$dbpassword="a1234";
$dbname="Admin_login_Codefreedom";

$con= new mysqli($dbhost,$username,$dbpassword,$dbname);
if($con-> connect_error){
	 die("Connection failed: " . $db->connect_error);
}

?>
