<?php 
include'dbconnect.php';
session_start();

if($_SERVER["REQUEST_METHOD"] == "POST"){
	$email = mysqli_real_escape_string($con,$_POST['email']);
	$password =mysqli_real_escape_string($con,$_POST['password']);
	$sql = "SELECT * FROM Admin_login_Codefreedom where email='$email' and password='$password' ";
	$query=mysqli_query($con,$sql);
	$row_check = mysqli_num_rows($query);
	if($row_check==1){
		$_SESSION['email'] = $email;
		header('location:Admin_home_page.php');
	}
	else{
		echo '<script>alert ("Please Enter Currect Information");
				location="Admin_login.php";
				</script>';
	}
}



?>