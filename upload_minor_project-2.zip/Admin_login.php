<?php 

session_start();
if(isset($_SESSION['email'])){
	header('location:Admin_home_page.php');
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link rel="stylesheet" href="bootstrap/css/font-awesome-5.8.1.css">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="bootstrap/css/mdb.css">
    <link rel="stylesheet" href="bootstrap/css/style.css">
    <title>CodeFreedom</title>
    <style>
        body{
            background-color:cornsilk;
        }
    </style>
</head>
<body>

<!----------Navbar---------------->
<nav class="navbar navbar-expand-md bg-primary navbar-light  w-100" id="top" style="z-index: 10;">
    <a href="#" class="navbar-brand ml-1 font-weight-bold" style="letter-spacing: 1px;font-family: 'Old English Text MT';">
        website_Logo
    </a>
    <button class="navbar-toggler " type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul  class="navbar-nav ml-auto mr-5">
            <li class="nav-item ">
                <a class="nav-link" href="#">Home</a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" href="#">About</a>
            </li>
			<li class="nav-item ">
                <a class="nav-link" href="#">Services</a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" href="#">Contact Us</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="Admin_login.php">Admin</a>
            </li>
        </ul>
    </div>
</nav>
<!--------------------------Admin login page--------------------------------------->
<div class="mx-auto card col-md-8 col-lg-6 col-sm-6 mt-5">
    <h4 class="text-center font-weight-bold mt-3">Admin_Login_page</h4>
    <form action="Admin_login_validate.php" method="post" class="mt-5">
        <div class="form-group">
            <label for="exampleInputEmail1">Email address</label>
            <input type="email" name="email" required class="form-control" autocomplete="off" id="exampleInputEmail1" aria-describedby="emailHelp">
            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Password</label>
            <input type="password" name="password" required class="form-control" id="exampleInputPassword1" >
        </div>
        <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" id="exampleCheck1">
            <label class="form-check-label" for="exampleCheck1">Check me out</label>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Login</button>
    </form><br>
</div>


<br>
<!-----------------------Fooder Section----------------->
<footer id="footer">
    <div class="footer-top bg-dark" style="background-color: white">
        <div class="container"><br>
            <div class="row">
                <div class="col-lg-4 col-md-6 footer-info">
                    <h4 class="font-weight-bold text-white">
                        Get Know About Us
                    </h4>
                    <a  href="#">Home</a><br>
                    <a  href="#">About</a><br>
                    <a  href="#">Services</a><br>
                    <a  href="#">Contact Us</a><br><br>
                </div>
                <div class="col-lg-4 col-md-6 footer-contact">
                    <h4 class="font-weight-bold text-white">Contact With Us</h4>
                    <a href="#" class="twitter mr-2" style="font-size: 30px;"target="null" target="null"><i  class="fab fa-twitter"></i></a>
                    <a href="#" class="facebook m-2" style="font-size: 30px;"target="null" target="null"><i class="fab fa-facebook-square"></i></a>
                    <a href="#" class="instragram m-2" style="font-size: 30px;"target="null" target="null"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="whatsapp m-2" style="font-size: 30px;"target="null" target="null"><i class="fab fa-whatsapp"></i></a>
                    <br><br><span class="text-white">Ph.No:  9999999999 / 99999999999</span><br>
                    <span>Email: <a href="#" target="null">xyzxyz@gmail.com</a> </span>
                    <br>
                </div>
                <div class="col-lg-4 col-md-6 footer-contact">
                    <p class="mt-4 ml-3" style="color: #8c9eff;font-size: 14px;font-family: Algerian; letter-spacing: 1px;"><strong style="font-size: 19px;color: red;">WEBSITE NAME</strong>
                        <br>About your website</p>
                </div>

            </div>
        </div>
    </div>
</footer>
<script>
    let pass_box = document.querySelector("#exampleInputPassword1");
    let check_box = document.querySelector("#exampleCheck1");
    check_box.addEventListener('click',function () {

        let check_attribute = pass_box.getAttribute('type');
        if(check_attribute==='password'){
            pass_box.setAttribute('type','text');
        }
        else {
            pass_box.setAttribute('type','password');
        }
    })
</script>
<script src="bootstrap/js/jquery-3.3.1.min.js"></script>
<script src="bootstrap/js/popper.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="bootstrap/js/mdb.min.js"></script>
<script src="package/js/swiper.min.js"></script>
</body>
</html>